/// <reference types="astro/client" />
/// <reference path="content.d.ts" />